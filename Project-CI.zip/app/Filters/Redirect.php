<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class Redirect implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (!session()->has('isLoggedIn')) {
            return redirect()->to(site_url('login'));
        } else if (session()->has('redirect_contact')) {
            session()->remove('redirect_contact');
            return redirect()->to(base_url('contact'));
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // // Cek apakah request adalah POST dan berhasil login
        // if ($request->isPost() && session()->get('isLoggedIn')) {
        //     // Redirect ke halaman Contact
        //     return redirect()->to(base_url('contact'));
        // }
    }
}
